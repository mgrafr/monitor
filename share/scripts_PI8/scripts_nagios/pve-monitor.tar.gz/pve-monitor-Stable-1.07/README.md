[![Build Status](https://travis-ci.org/dpiquet/pve-monitor.svg?branch=master)](https://travis-ci.org/dpiquet/pve-monitor)

pve-monitor is a Nagios plugin to monitor Proxmox VE clusters.

It can monitor openvz and qemu virtual machines, storages and cluster nodes without installing
software on your monitored resources. It uses the Proxmox VE API to query the cluster status.

See http://pve-monitor.scriptutils.com for details and installation notes.

Documentation française: http://pve-monitor.scriptutils.com/francais/presentation/
